package com.example.storesapplication.Activitys

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.storesapplication.Adapters.AddProductAdapter
import com.example.storesapplication.Adapters.MoreDetailsAdapter
import com.example.storesapplication.Inteface.AddproductInterFace
import com.example.storesapplication.Inteface.MoredetailsAdapterInterface
import com.example.storesapplication.Networking.APIResponceModel
import com.example.storesapplication.Networking.APIServices
import com.example.storesapplication.Networking.RequestMethods
import com.example.storesapplication.Progress.Show
import com.example.storesapplication.R
import com.example.storesapplication.ResponceModels.UploadImageModel
import com.example.storesapplication.Utility.Utility
import com.google.gson.JsonObject
import com.libizo.CustomEditText
import org.json.JSONObject


class AddProduct : AppCompatActivity(), AdapterView.OnItemSelectedListener,
    AdapterView.OnItemClickListener, View.OnClickListener, MoredetailsAdapterInterface,AddproductInterFace {

    var pname: CustomEditText? = null
    var pdescription: CustomEditText? = null
    var pprice: CustomEditText? = null
    var pdiscountprice: CustomEditText? = null
    var pdiscountpercentage: CustomEditText? = null
    var detailstype: CustomEditText? = null
    var detailsvalue: CustomEditText? = null


    var adddimagelistrecyclerview: RecyclerView? = null
    var producttypespinner: Spinner? = null
    var producttypecategory: Spinner? = null
    var addmoredetailslist: ListView? = null
    var addmorebtn: Button? = null
    var sizesview: LinearLayout? = null

    var ssizebutton: Button? = null
    var msizebutton: Button? = null
    var lsizebutton: Button? = null
    var xlsizebutton: Button? = null
    var xxlsizebutton: Button? = null
    var adddetailsbtn: Button? = null

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var mAdapter: AddProductAdapter? = null

    var jsondetails: JSONObject = JSONObject()
    var alertDialog: AlertDialog? = null
    var scrollview: ScrollView? = null

    var PICK_IMAGE = 12
    var PICK_CAMERA_IMAGE = 13

    var imagesArray = ArrayList<String>()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)
        pname = findViewById(R.id.pname)
        pdescription = findViewById(R.id.pdescription)
        pprice = findViewById(R.id.pprice)
        pdiscountprice = findViewById(R.id.pdiscountprice)
        pdiscountpercentage = findViewById(R.id.pdiscountpercentage)
        adddimagelistrecyclerview = findViewById(R.id.adddimagelist)
        producttypespinner = findViewById(R.id.producttypespinner)
        producttypecategory = findViewById(R.id.producttypecategory)
        addmoredetailslist = findViewById(R.id.addmoredetailslist)
        addmorebtn = findViewById(R.id.addmorebtn)
        sizesview = findViewById(R.id.sizesview)

        ssizebutton = findViewById(R.id.ssizebutton)
        msizebutton = findViewById(R.id.msizebutton)
        lsizebutton = findViewById(R.id.lsizebutton)
        xlsizebutton = findViewById(R.id.xlsizebutton)
        xxlsizebutton = findViewById(R.id.xxlsizebutton)
        scrollview = findViewById(R.id.scrollview)

        ssizebutton?.setOnClickListener(this)
        msizebutton?.setOnClickListener(this)
        lsizebutton?.setOnClickListener(this)
        xlsizebutton?.setOnClickListener(this)
        xxlsizebutton?.setOnClickListener(this)
        addmorebtn?.setOnClickListener(this)


        adddimagelistrecyclerview?.setHasFixedSize(true)
        layoutManager =  LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);

        adddimagelistrecyclerview?.setLayoutManager(layoutManager);

        mAdapter = AddProductAdapter(applicationContext,imagesArray);
        mAdapter!!.delegate = this
        adddimagelistrecyclerview?.setAdapter(mAdapter);

        mAdapter?.setItemClickListener(object : AddProductAdapter.ItemClickListener {
            override fun onItemClick(view: View?, position: Int) {
                if (position == 0) {
                    alertDailogformedia()
                }
            }
        })

        val categories: MutableList<String> = ArrayList()
        categories.add("Select")
        categories.add("Cloth")
        categories.add("Grocery")
        val dataAdapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        producttypespinner?.adapter = dataAdapter
        producttypecategory?.adapter = dataAdapter
        producttypespinner?.onItemSelectedListener = this



    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
        if(p2 == 1) {
            sizesview?.visibility = View.VISIBLE
        }
        if(p2 == 2) {
            sizesview?.visibility = View.GONE
        }
        if(p2 == 0) {
            sizesview?.visibility = View.GONE
        }
    }

    override fun onItemClick(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {

    }

    fun addDetailsDailog() {
        val dialogBuilder: AlertDialog.Builder = AlertDialog.Builder(this)

        val inflater = this.layoutInflater
        val dialogView: View = inflater.inflate(R.layout.add_more_details, null)
        dialogBuilder.setView(dialogView)

         detailstype = dialogView.findViewById<View>(R.id.detailstype) as CustomEditText
         detailsvalue = dialogView.findViewById<View>(R.id.detailsvalue) as CustomEditText
         adddetailsbtn = dialogView.findViewById<View>(R.id.adddetailsbtn) as Button
        adddetailsbtn?.setOnClickListener(this)

        alertDialog = dialogBuilder.create()
        alertDialog?.show()

    }

    fun alertDailogformedia() {
        val builder = AlertDialog.Builder(this)
        //set title for alert dialog
        builder.setTitle("Upload Image")
        //set message for alert dialog
        builder.setMessage("Please select gallery or Camera to upload Image")
        builder.setIcon(applicationContext.resources.getDrawable(R.drawable.uploadimage))

        //performing cancel action
        builder.setNeutralButton("Cancel"){dialogInterface , which ->
            Toast.makeText(applicationContext,"clicked cancel\n operation cancel",Toast.LENGTH_LONG).show()
        }


        //performing positive action
        builder.setPositiveButton("Gallery"){dialogInterface, which ->
            val intent = Intent()
            intent.type = "image/*"
            intent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE)
        }

        //performing negative action
        builder.setNegativeButton("Camera"){dialogInterface, which ->
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(intent, PICK_CAMERA_IMAGE)
        }
        // Create the AlertDialog
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE) {

            if(data?.data != null) {
                 Show.getInstance().showProgress(this,"Please wait Uploading Image..")
                 var imageUri = data?.getData();
                 var imageStream = getContentResolver().openInputStream(imageUri!!);
                 var selectedImage = BitmapFactory.decodeStream(imageStream);
                var base64image = Utility.converttoBitmap(selectedImage)
                var body = JSONObject()
                body.put("imagename","imahename")
                body.put("image",base64image)
                uploadImage(body)

            }
        }
        if(requestCode == PICK_CAMERA_IMAGE) {
            if (data?.data != null && resultCode == RESULT_OK) {
                val bitmap: Bitmap? = data.extras!!["data"] as Bitmap?
                var base64image = Utility.converttoBitmap(bitmap)
                var body = JSONObject()
                body.put("imagename","imahename")
                body.put("image",base64image)
                uploadImage(body)
            }
        }

    }

    fun uploadImage(body: JSONObject) {
        APIServices.getInstance().apiforuploadImage(applicationContext,body, RequestMethods.addImages, object :
            APIResponceModel() {
            override fun responceuploadImage(uploadImageModel: UploadImageModel?) {
                Log.e("imageid"," " +uploadImageModel?.getImageid())
                imagesArray.add(uploadImageModel!!.getImageid())
                mAdapter?.notifyDataSetChanged()
                Show.getInstance().dismiss()
            }
            override fun onFailure(responce: JSONObject?) {
                Show.getInstance().dismiss()
            }
        })
    }


    override fun onClick(view: View?) {
        if(view?.id == R.id.ssizebutton) {
            Log.e("tag","tag value"+ssizebutton?.tag)
            if (ssizebutton?.getTag()?.equals("1")!!) {
                ssizebutton?.setTag("0")
                ssizebutton?.setBackgroundColor(applicationContext.resources.getColor(R.color.colorPrimary))
                ssizebutton?.setTextColor(Color.WHITE)
            } else {
                ssizebutton?.setTag("1")
                ssizebutton?.setBackgroundColor(Color.WHITE)
                ssizebutton?.setTextColor(Color.BLACK)
            }
        }
        if(view?.id == R.id.msizebutton) {
            if (msizebutton?.getTag()?.equals("1")!!) {
                msizebutton?.setTag("0")
                msizebutton?.setBackgroundColor(applicationContext.resources.getColor(R.color.colorPrimary))
                msizebutton?.setTextColor(Color.WHITE)
            } else {
                msizebutton?.setTag("1")
                msizebutton?.setBackgroundColor(Color.WHITE)
                msizebutton?.setTextColor(Color.BLACK)
            }
        }
        if(view?.id == R.id.lsizebutton) {
            if (lsizebutton?.getTag()?.equals("1")!!) {
                lsizebutton?.setTag("0")
                lsizebutton?.setBackgroundColor(applicationContext.resources.getColor(R.color.colorPrimary))
                lsizebutton?.setTextColor(Color.WHITE)
            } else {
                lsizebutton?.setTag("1")
                lsizebutton?.setBackgroundColor(Color.WHITE)
                lsizebutton?.setTextColor(Color.BLACK)
            }
        }
        if(view?.id == R.id.xlsizebutton) {
            if (xlsizebutton?.getTag()?.equals("1")!!) {
                xlsizebutton?.setTag("0")
                xlsizebutton?.setBackgroundColor(applicationContext.resources.getColor(R.color.colorPrimary))
                xlsizebutton?.setTextColor(Color.WHITE)
            } else {
                xlsizebutton?.setTag("1")
                xlsizebutton?.setBackgroundColor(Color.WHITE)
                xlsizebutton?.setTextColor(Color.BLACK)
            }
        }
        if(view?.id == R.id.xxlsizebutton) {
            if (xxlsizebutton?.getTag()?.equals("1")!!) {
                xxlsizebutton?.setTag("0")
                xxlsizebutton?.setBackgroundColor(applicationContext.resources.getColor(R.color.colorPrimary))
                xxlsizebutton?.setTextColor(Color.WHITE)
            } else {
                xxlsizebutton?.setTag("1")
                xxlsizebutton?.setBackgroundColor(Color.WHITE)
                xxlsizebutton?.setTextColor(Color.BLACK)
            }
        }
        if (view?.id == R.id.addmorebtn) {
            addDetailsDailog()
        }
        if (view?.id == R.id.adddetailsbtn) {
            if(detailstype?.text!!.isEmpty()) {
                detailstype!!.setError("please enter Details Type")
                return
            }
            if(detailsvalue?.text!!.isEmpty()) {
                detailsvalue!!.setError("please enter Details Value")
                return
            }
            jsondetails.put(detailstype?.text.toString()!!,detailsvalue?.text!!.toString())

            alertDialog?.dismiss()
            var moredetailsadapter = MoreDetailsAdapter(jsondetails,applicationContext)
            moredetailsadapter.adapterInterface = this
            addmoredetailslist?.adapter = moredetailsadapter
            Utility.setListViewHeightBasedOnChildren(addmoredetailslist)
            addmoredetailslist?.deferNotifyDataSetChanged()

            Log.e("addben","addede")
        }
    }

    override fun deleteItem(key: String?) {
        jsondetails.remove(key)
        var moredetailsadapter = MoreDetailsAdapter(jsondetails,applicationContext)
        addmoredetailslist?.adapter = moredetailsadapter
        moredetailsadapter.adapterInterface = this
        Utility.setListViewHeightBasedOnChildren(addmoredetailslist)
        addmoredetailslist?.deferNotifyDataSetChanged()
    }

    override fun deleteImage(position: Int) {
        Show.getInstance().showProgress(this,"Deleting Image Please Wait")
        var body =  JSONObject()
        body.put("imageid",imagesArray?.get(position))
        APIServices.getInstance().apiforDeleteImage(applicationContext,body,RequestMethods.deleteImage, object :  APIResponceModel() {
            override fun onSuccess() {
                Show.getInstance().dismiss()
            }
            override fun onFailure(responce: JSONObject?) {
                Show.getInstance().dismiss()
            }
        })
        imagesArray?.removeAt(position)
        mAdapter?.notifyDataSetChanged()

    }
}