package com.example.storesapplication.Activitys

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.storesapplication.R


class HomeActivity : AppCompatActivity() {

    var productslist: RecyclerView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        productslist = findViewById(R.id.productslist)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.addproduct -> {
            movetoaddproduct()
            true
        }
        R.id.order -> {

            true
        }
        R.id.logout -> {
            logout()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    fun logout() {

    }
    fun movetoaddproduct() {
        val addproduct = Intent(this, AddProduct::class.java)
        startActivity(addproduct)
    }
}