package com.example.storesapplication.Activitys

import android.content.Intent
import android.os.Bundle
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.storesapplication.Networking.*
import com.example.storesapplication.Preferences.Preferences
import com.example.storesapplication.Progress.Show
import com.example.storesapplication.R
import com.example.storesapplication.ResponceModels.OwnerLoginResponceModel
import org.json.JSONObject


class RegisteredActivity : AppCompatActivity() {
    var name: EditText? = null
    var email: EditText? = null
    var loginemail: EditText? = null
    var loginpassword: EditText? = null
    var password: EditText? = null
    var phonenumber: EditText? = null
    var ownerstorename: EditText? = null


    var registerbtn: Button? = null
    var loginbutton: Button? = null
    var logintextview: TextView? = null
    var registertextview: TextView? = null

    var registerview: LinearLayout? = null
    var loginview: LinearLayout? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registered)
        name = findViewById(R.id.ownername)
        email = findViewById(R.id.owneremail)
        password = findViewById(R.id.ownerpassword)
        loginemail = findViewById(R.id.loginemail)
        loginpassword = findViewById(R.id.loginpassword)
        phonenumber = findViewById(R.id.ownerphonenumber)
        registerbtn = findViewById(R.id.registerbtn)
        loginbutton = findViewById(R.id.loginbutton)

        registerview = findViewById(R.id.registerview)
        loginview = findViewById(R.id.loginview)
        registertextview = findViewById(R.id.registertextview)
        ownerstorename = findViewById(R.id.ownerstorename)



        logintextview = findViewById(R.id.logintextview)


        val content = SpannableString("Login")
        content.setSpan(UnderlineSpan(), 0, content.length, 0)
        logintextview?.setText(content)

        val contentregistertextview = SpannableString("Register")
        contentregistertextview.setSpan(UnderlineSpan(), 0, content.length, 0)
        registertextview?.setText(contentregistertextview)




        registerbtn?.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {

                Show.getInstance().showProgress(this@RegisteredActivity,"Loading..")

                var ownerregisterbody = JSONObject()
                ownerregisterbody.put("ownername",name?.text)
                ownerregisterbody.put("email",email?.text)
                ownerregisterbody.put("password",password?.text)
                ownerregisterbody.put("phoneNumber",phonenumber?.text)
                ownerregisterbody.put("storename",ownerstorename?.text)

                Network.getInstance(applicationContext).postRequest(ownerregisterbody, RequestMethods.registerOwner,object: NetworkCallBack {
                    override fun onSuccess(responce: JSONObject?) {
                        Show.getInstance().dismiss()
                        Log.e("registersucce","register success")
                        Show.alertDialogShow(this@RegisteredActivity, "Successfully Register for store")
                        logintextview?.performClick()
                    }
                    override fun onFailure(responce: JSONObject?) {
                        Show.getInstance().dismiss()
                        Log.e("register fail","register fail")
                    }
                })
            }
        })
        logintextview?.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                registerview?.visibility = View.GONE
                loginview?.visibility = View.VISIBLE


            }
        })

        registertextview?.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                registerview?.visibility = View.VISIBLE
                loginview?.visibility = View.GONE
            }
        })

        loginbutton?.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                Show.getInstance().showProgress(this@RegisteredActivity,"Loading..")

                var ownerloginbody = JSONObject()
                ownerloginbody.put("email",loginemail?.text)
                ownerloginbody.put("password",loginpassword?.text)

                APIServices.getInstance().apiforOwnerLogin(applicationContext,ownerloginbody, RequestMethods.ownerlogin, object :
                    APIResponceModel() {
                    override fun onOwnerLogin(ownerLoginResponceModel: OwnerLoginResponceModel?) {
                        Show.getInstance().dismiss()
                        Preferences.getInstace(applicationContext).geteditor().putString(Preferences.owneruserid,ownerLoginResponceModel?.owneruserid).commit()
                        Preferences.getInstace(applicationContext).geteditor().putString(Preferences.email,ownerLoginResponceModel?.email).commit()
                        Preferences.getInstace(applicationContext).geteditor().putString(Preferences.storename,ownerLoginResponceModel?.storename).commit()

                        val homeActivity = Intent(this@RegisteredActivity,HomeActivity::class.java)
                        startActivity(homeActivity)

                    }
                    override fun onFailure(responce: JSONObject?) {
                        Show.getInstance().dismiss()
                    }
                })

            }
        })
    }
}