package com.example.storesapplication.Adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;

import com.example.storesapplication.Inteface.AddproductInterFace;
import com.example.storesapplication.Networking.APIResponceModel;
import com.example.storesapplication.Networking.APIServices;
import com.example.storesapplication.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AddProductAdapter extends RecyclerView.Adapter<AddProductAdapter.ViewHolder> {


    private LayoutInflater mInflater;
    private ItemClickListener mClickListener;
    private ArrayList<String> imagesArray;
    private Context context;
    public AddproductInterFace delegate;
    public  AddProductAdapter(Context context, ArrayList<String> imagesArray) {
        this.imagesArray = imagesArray;
        this.context = context;
    }
    @Override
    public AddProductAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            Context context = parent.getContext();
            LayoutInflater inflater = LayoutInflater.from(context);

            // Inflate the custom layout
            View contactView = inflater.inflate(R.layout.addproductimagelayout, parent, false);

            // Return a new holder instance
            ViewHolder viewHolder = new ViewHolder(contactView);
            return viewHolder;
    }

    // Involves populating data into the item through holder
    @Override
    public void onBindViewHolder(AddProductAdapter.ViewHolder holder, final int position) {
            // Get the data model based on position
        ImageView deleteimage = (ImageView)holder.itemView.findViewById(R.id.deleteimage);
        final ImageView addproductimge = (ImageView)holder.itemView.findViewById(R.id.addproductimge);
        if (position == 0 ){
            deleteimage.setVisibility(View.GONE);
        } else  {
            deleteimage.setVisibility(View.VISIBLE);
            APIServices.getInstance().apiforLoadImage(context, imagesArray.get(position-1), new APIResponceModel() {

                @Override
                public void responceLoadImage(Bitmap image) {
                    addproductimge.setImageBitmap(image);
                }

                @Override
                public void onFailure(JSONObject responce) {

                }
            });
            deleteimage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    delegate.deleteImage(position-1);
                }
            });
        }
        }

        @Override
        public int getItemCount() {
                return imagesArray.size() + 1;
                }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ViewHolder(View itemView) {
            super(itemView);

            itemView.setOnClickListener(this);
        }
        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }

      public void setItemClickListener(ItemClickListener itemClickListener) {
            this.mClickListener = itemClickListener;
        }
        public interface ItemClickListener {
            void onItemClick(View view, int position);
        }

}