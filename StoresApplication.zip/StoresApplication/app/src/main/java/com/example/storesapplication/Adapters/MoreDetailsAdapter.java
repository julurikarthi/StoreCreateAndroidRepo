package com.example.storesapplication.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.storesapplication.Inteface.MoredetailsAdapterInterface;
import com.example.storesapplication.R;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

public class MoreDetailsAdapter extends BaseAdapter {
    JSONObject data;
    Context context;
    LayoutInflater layoutInflater;
    Iterator<String> keys;
    ArrayList<String> arraykeys = new ArrayList<>();
   public MoredetailsAdapterInterface adapterInterface;
   public  MoreDetailsAdapter(JSONObject data, Context context) {
       this.context = context;
       layoutInflater = LayoutInflater.from(context);
       this.data = data;
       keys = data.keys();
       while (keys.hasNext()) {
           String key = keys.next();
           try{
               arraykeys.add(key);
           }
           catch(Exception e){
               e.printStackTrace();
           }
       }
    }
    @Override
    public int getCount() {
        return arraykeys.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        View convertView= layoutInflater.inflate(R.layout.more_details_view, null);

        TextView itemtype=(TextView)convertView.findViewById(R.id.itemtype);
        TextView itemvalue=(TextView)convertView.findViewById(R.id.itemvalue);
        ImageView deleteItem=(ImageView)convertView.findViewById(R.id.deleteItem);

        itemtype.setText(arraykeys.get(i)+ " : ");
        try {
            itemvalue.setText(data.getString(arraykeys.get(i)));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adapterInterface.deleteItem(arraykeys.get(i));
            }
        });
        return convertView;
    }
}
