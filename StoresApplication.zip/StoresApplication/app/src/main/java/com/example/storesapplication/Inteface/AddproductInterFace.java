package com.example.storesapplication.Inteface;

public interface AddproductInterFace {

    public void deleteImage(int position);

}
