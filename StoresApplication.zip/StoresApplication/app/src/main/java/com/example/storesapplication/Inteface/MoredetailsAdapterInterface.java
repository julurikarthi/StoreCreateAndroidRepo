package com.example.storesapplication.Inteface;

public interface MoredetailsAdapterInterface {
    void deleteItem(String key);
}
