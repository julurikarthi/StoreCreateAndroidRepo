package com.example.storesapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.storesapplication.Activitys.HomeActivity
import com.example.storesapplication.Activitys.RegisteredActivity
import com.example.storesapplication.Networking.*
import com.example.storesapplication.Preferences.Preferences
import com.example.storesapplication.ResponceModels.OwnerLoginResponceModel
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        if (Preferences.getInstace(applicationContext).getsharedPreference().contains(Preferences.owneruserid)) {
            val registeredActivity = Intent(this, HomeActivity::class.java)
            startActivity(registeredActivity)
        } else {
            val registeredActivity = Intent(this, RegisteredActivity::class.java)
            startActivity(registeredActivity)
        }



//        val obj = JSONObject()
////        obj.put("ownername","karthik")
//        obj.put("email","jkarthik31@gmail.com")
//        obj.put("password","123123123")
////        obj.put("phoneNumber","8099987468")


    }


    override fun onResume() {
        super.onResume()

    }
}