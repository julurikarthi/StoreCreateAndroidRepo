package com.example.storesapplication.Networking;

import android.graphics.Bitmap;
import android.media.Image;

import com.example.storesapplication.ResponceModels.AddressResponceModel;
import com.example.storesapplication.ResponceModels.CategoriesResponceModel;
import com.example.storesapplication.ResponceModels.CustomerLoginResponceModel;
import com.example.storesapplication.ResponceModels.OfferResponceModel;
import com.example.storesapplication.ResponceModels.OrderResponceModel;
import com.example.storesapplication.ResponceModels.OwnerLoginResponceModel;
import com.example.storesapplication.ResponceModels.ProductResponceModel;
import com.example.storesapplication.ResponceModels.UploadImageModel;

import org.json.JSONObject;

public abstract class APIResponceModel {

    public void onOwnerLogin(OwnerLoginResponceModel ownerLoginResponceModel) {

    }
    public void customerlogin(CustomerLoginResponceModel customerLoginResponceModel) {

    }
    public void productresponcemodel(ProductResponceModel ownerLoginResponceModel) {

    }
    public void getaddress(AddressResponceModel addressResponceModel) {

    }

    public void  getCategories(CategoriesResponceModel categoriesResponceModel) {

    }

    public void offersresponce(OfferResponceModel offerResponceModel) {

    }

    public void orderResponceModel(OrderResponceModel orderResponceModel) {

    }

    public void responceuploadImage(UploadImageModel uploadImageModel) {

    }

    public void responceLoadImage(Bitmap image) {

    }
    public void onSuccess(){

    }

    public abstract void onFailure(JSONObject responce);


}
