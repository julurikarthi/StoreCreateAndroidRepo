package com.example.storesapplication.Networking;

import android.content.Context;
import android.graphics.Bitmap;

import com.example.storesapplication.ResponceModels.AddressResponceModel;
import com.example.storesapplication.ResponceModels.CategoriesResponceModel;
import com.example.storesapplication.ResponceModels.CustomerLoginResponceModel;
import com.example.storesapplication.ResponceModels.OfferResponceModel;
import com.example.storesapplication.ResponceModels.OrderResponceModel;
import com.example.storesapplication.ResponceModels.OwnerLoginResponceModel;
import com.example.storesapplication.ResponceModels.ProductResponceModel;
import com.example.storesapplication.ResponceModels.UploadImageModel;
import com.example.storesapplication.Utility.Utility;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

public class APIServices {

    static  APIServices instace = null;

    public static APIServices getInstance(){
        instace = new APIServices();
        return  instace;
    }


    public void apiforownerRegister(Context context, JSONObject body, String method, NetworkCallBack callBack) {
        Network.getInstance(context).postRequest(body,method,callBack);
    }

    public void apiforOwnerLogin(Context context, JSONObject body, String method, final APIResponceModel apiResponceModel) {
            Network.getInstance(context).postRequest(body, method, new NetworkCallBack() {
                @Override
                public void onSuccess(JSONObject responce) {
                    OwnerLoginResponceModel object = convertoModel(responce,OwnerLoginResponceModel.class);
                    apiResponceModel.onOwnerLogin(object);
                }

                @Override
                public void onFailure(JSONObject responce) {
                    apiResponceModel.onFailure(responce);
                }
            });
    }

    public void apiforcustomerLogin(Context context, JSONObject body, String method, final APIResponceModel apiResponceModel) {
        Network.getInstance(context).postRequest(body, method, new NetworkCallBack() {
            @Override
            public void onSuccess(JSONObject responce) {
                CustomerLoginResponceModel object = convertoModel(responce, CustomerLoginResponceModel.class);
                apiResponceModel.customerlogin(object);
            }

            @Override
            public void onFailure(JSONObject responce) {
                apiResponceModel.onFailure(responce);
            }
        });
    }

    public void apiforgetproducts(Context context, JSONObject body, String method, final APIResponceModel apiResponceModel) {
        Network.getInstance(context).postRequest(body, method, new NetworkCallBack() {
            @Override
            public void onSuccess(JSONObject responce) {
                ProductResponceModel object = convertoModel(responce, ProductResponceModel.class);
                apiResponceModel.productresponcemodel(object);
            }

            @Override
            public void onFailure(JSONObject responce) {
                apiResponceModel.onFailure(responce);
            }
        });
    }

    public void apiforgetaddress(Context context, JSONObject body, String method, final APIResponceModel apiResponceModel) {
        Network.getInstance(context).postRequest(body, method, new NetworkCallBack() {
            @Override
            public void onSuccess(JSONObject responce) {
                AddressResponceModel object = convertoModel(responce, AddressResponceModel.class);
                apiResponceModel.getaddress(object);
            }

            @Override
            public void onFailure(JSONObject responce) {
                apiResponceModel.onFailure(responce);
            }
        });
    }

    public void apiforgetCategories(Context context, JSONObject body, String method, final APIResponceModel apiResponceModel) {
        Network.getInstance(context).postRequest(body, method, new NetworkCallBack() {
            @Override
            public void onSuccess(JSONObject responce) {
                CategoriesResponceModel object = convertoModel(responce, CategoriesResponceModel.class);
                apiResponceModel.getCategories(object);
            }

            @Override
            public void onFailure(JSONObject responce) {
                apiResponceModel.onFailure(responce);
            }
        });
    }

    public void apiforoffersresponce(Context context, JSONObject body, String method, final APIResponceModel apiResponceModel) {
        Network.getInstance(context).postRequest(body, method, new NetworkCallBack() {
            @Override
            public void onSuccess(JSONObject responce) {
                OfferResponceModel object = convertoModel(responce, OfferResponceModel.class);
                apiResponceModel.offersresponce(object);
            }

            @Override
            public void onFailure(JSONObject responce) {
                apiResponceModel.onFailure(responce);
            }
        });
    }
    public void apifororderResponce(Context context, JSONObject body, String method, final APIResponceModel apiResponceModel) {
        Network.getInstance(context).postRequest(body, method, new NetworkCallBack() {
            @Override
            public void onSuccess(JSONObject responce) {
                OrderResponceModel object = convertoModel(responce, OrderResponceModel.class);
                apiResponceModel.orderResponceModel(object);
            }

            @Override
            public void onFailure(JSONObject responce) {
                apiResponceModel.onFailure(responce);
            }
        });
    }

    public void apiforuploadImage(Context context, JSONObject body, String method, final APIResponceModel apiResponceModel){
        Network.getInstance(context).postRequest(body, method, new NetworkCallBack() {
            @Override
            public void onSuccess(JSONObject responce) {
                UploadImageModel object = convertoModel(responce, UploadImageModel.class);
                apiResponceModel.responceuploadImage(object);
            }

            @Override
            public void onFailure(JSONObject responce) {
                apiResponceModel.onFailure(responce);
            }
        });
    }

    public void  apiforLoadImage(Context context, String imageid,final APIResponceModel apiResponceModel) {
        Network.getInstance(context).getRequestforImage(imageid, new NetworkCallBack() {
            @Override
            public void onSuccess(JSONObject responce) {
                UploadImageModel object = convertoModel(responce, UploadImageModel.class);
                Bitmap bitmap = Utility.convertBase64toImage(object.image);
                if(bitmap != null) {
                    apiResponceModel.responceLoadImage(bitmap);
                } else {
                    JSONObject jsonObject = new JSONObject();
                    try {
                        jsonObject.put("status","fail");
                        jsonObject.put("error","bitmap convertfail");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    apiResponceModel.onFailure(jsonObject);
                }
            }

            @Override
            public void onFailure(JSONObject responce) {
                apiResponceModel.onFailure(responce);
            }
        });
    }
    public void  apiforDeleteImage(Context context,JSONObject body, String method,final APIResponceModel apiResponceModel) {
        Network.getInstance(context).postRequest(body, method, new NetworkCallBack() {
            @Override
            public void onSuccess(JSONObject responce) {
                apiResponceModel.onSuccess();
            }

            @Override
            public void onFailure(JSONObject responce) {
                apiResponceModel.onFailure(responce);
            }

        });
    }

        private  <T> T convertoModel(JSONObject responce, Class<T> classOfT){
         JsonParser parser = new JsonParser();
         JsonElement mJson =  parser.parse(responce.toString());
         Gson gson = new Gson();
         return gson.fromJson(mJson, classOfT);
    }

}
