package com.example.storesapplication.Networking;

public class APIsUtilities {

    public static void uploadImage(){
        
    }
}
