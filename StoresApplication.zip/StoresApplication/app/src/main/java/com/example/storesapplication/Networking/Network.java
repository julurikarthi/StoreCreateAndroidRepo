package com.example.storesapplication.Networking;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interceptors.GzipRequestInterceptor;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.gson.JsonObject;
import com.jacksonandroidnetworking.JacksonParserFactory;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.POST;

import static com.android.volley.Request.*;

public class Network {

    private static Network instance = null;

    private String baseurl = "http://createshop.co.in/endpoint.php";
    static RequestQueue queue = null;
    static Context thiscontext;

    public static Network getInstance(Context context) {
        thiscontext = context;
        queue = Volley.newRequestQueue(context);
        instance = new Network();
        return instance;
    }

    public void postRequest(JSONObject body, String methodname, final NetworkCallBack callBack) {
        JSONObject methodobject = new JSONObject();
        JSONObject bodyobject = new JSONObject();
        try {
            methodobject.put("method", methodname);
            methodobject.put("data", body);
            bodyobject.put("params", methodobject);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.e("body", bodyobject.toString());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Method.POST, baseurl, bodyobject,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.e("responce success ", response.toString());
                        if (response.optString("status").equals("failure")) {
                            callBack.onFailure(response);
                        } else {
                            callBack.onSuccess(response);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error", error.getMessage());
                JSONObject obj = new JSONObject();
                try {
                    obj.put("error",error.getMessage());
                    obj.put("status",error.networkResponse.statusCode);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
        Volley.newRequestQueue(thiscontext).add(jsonObjectRequest);
    }

    public void getRequestforImage(String imageid,final NetworkCallBack callBack){

        String imageurl = baseurl + "/?imageid=" + imageid;

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Method.GET, imageurl,null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.e("responce success ", response.toString());
                if (response.optString("status").equals("failure")) {
                    callBack.onFailure(response);
                } else {
                    callBack.onSuccess(response);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error", error.getMessage());
                JSONObject obj = new JSONObject();
                try {
                    obj.put("error",error.getMessage());
                    obj.put("status",error.networkResponse.statusCode);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });
        Volley.newRequestQueue(thiscontext).add(jsonObjectRequest);

    }
}