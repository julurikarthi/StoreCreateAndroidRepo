package com.example.storesapplication.Networking;


import org.json.JSONObject;

public interface NetworkCallBack {

    void onSuccess(JSONObject responce);
    void onFailure(JSONObject responce);
}
