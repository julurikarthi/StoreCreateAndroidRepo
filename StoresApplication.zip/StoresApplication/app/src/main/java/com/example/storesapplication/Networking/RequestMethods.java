package com.example.storesapplication.Networking;

public class RequestMethods {

    public static String registerOwner = "registerOwner";
    public static String customerregister = "customerregister";
    public static String addProduct = "addProduct";
    public static String customerlogin = "customerlogin";
    public static String ownerlogin = "ownerlogin";
    public static String getAddress = "getAddress";
    public static String getoffers = "getoffers";
    public static String getProducts = "getProducts";
    public static String getOrders = "getOrders";
    public static String getCustomerOrders = "getCustomerOrders";
    public static String deleteOwnerProduct = "deleteOwnerProduct";
    public static String placeOrder = "placeOrder";
    public static String addsubcategory = "addsubcategory";
    public static String addcategory = "addcategory";
    public static String getcategories = "getcategories";
    public static String getSubcategories = "getSubcategories";
    public static String getcatProducts = "getcatProducts";
    public static String addImages = "addImages";
    public static String deleteImage = "deleteImage";
}
