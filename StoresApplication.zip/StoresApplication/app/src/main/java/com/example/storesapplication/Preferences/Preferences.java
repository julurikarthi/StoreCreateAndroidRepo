package com.example.storesapplication.Preferences;

import android.content.Context;
import android.content.SharedPreferences;

public class Preferences {

    public static String owneruserid = "owneruserid";
    public static String storename = "storename";
    public static String email = "email";
    public static String phonenumber = "phonenumber";

    static Preferences instace = null;
    private static SharedPreferences editor;
    public static Preferences getInstace(Context context) {
        instace = new Preferences();
        editor = context.getSharedPreferences("OwnerAccountdetails", Context.MODE_PRIVATE);
        return instace;
    }

    public SharedPreferences.Editor geteditor(){
        return editor.edit();
    }
    public SharedPreferences getsharedPreference(){
        return editor;
    }

}

