package com.example.storesapplication.Progress;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.view.Window;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.example.storesapplication.R;

public class Show {
    public static Show s_m_oCShow;

    public Dialog m_Dialog;
    private ProgressBar m_ProgressBar;
    private Context context;


    public static Show getInstance() {
        if (s_m_oCShow == null) {
            s_m_oCShow = new Show();
        }
        return s_m_oCShow;
    }

    public void showProgress(Context m_Context, String message) {
        m_Dialog = new Dialog(m_Context);
        m_Dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        m_Dialog.setContentView(R.layout.progressbar);
        m_ProgressBar = (ProgressBar) m_Dialog.findViewById(R.id.progress_bar);
        TextView progressText = (TextView) m_Dialog.findViewById(R.id.progress_text);
        progressText.setText("" + message);
        progressText.setVisibility(View.VISIBLE);
        m_ProgressBar.setVisibility(View.VISIBLE);
        m_ProgressBar.setIndeterminate(true);
        m_Dialog.setCancelable(false);
        m_Dialog.setCanceledOnTouchOutside(false);
        m_Dialog.show();
    }

    public void dismiss() {
        if (m_Dialog != null && m_Dialog.isShowing()) {
            m_Dialog.dismiss();
        }
    }

    public static void alertDialogShow(Context context, String message)
    {
        final AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setMessage(message);
        alertDialog.setButton("OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
                alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }
}
