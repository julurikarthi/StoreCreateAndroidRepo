package com.example.storesapplication.ResponceModels;

public class AddressModel {
    private String plotno;

    private String street;

    private String nearby;

    private String colony;

    private String village;

    private String pincode;

    public void setPlotno(String plotno){
        this.plotno = plotno;
    }
    public String getPlotno(){
        return this.plotno;
    }
    public void setStreet(String street){
        this.street = street;
    }
    public String getStreet(){
        return this.street;
    }
    public void setNearby(String nearby){
        this.nearby = nearby;
    }
    public String getNearby(){
        return this.nearby;
    }
    public void setColony(String colony){
        this.colony = colony;
    }
    public String getColony(){
        return this.colony;
    }
    public void setVillage(String village){
        this.village = village;
    }
    public String getVillage(){
        return this.village;
    }
    public void setPincode(String pincode){
        this.pincode = pincode;
    }
    public String getPincode(){
        return this.pincode;
    }
}
