package com.example.storesapplication.ResponceModels;

import java.util.List;

public class AddressResponceModel {
    private List<AddressModel> address;

    private String status;

    public void setAddress(List<AddressModel> address){
        this.address = address;
    }
    public List<AddressModel> getAddress(){
        return this.address;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
}
