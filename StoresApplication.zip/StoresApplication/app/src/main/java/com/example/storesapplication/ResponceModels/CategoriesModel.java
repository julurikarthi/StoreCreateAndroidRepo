package com.example.storesapplication.ResponceModels;

public class CategoriesModel {
    private String parentId;

    private String category;

    public void setParentId(String parentId){
        this.parentId = parentId;
    }
    public String getParentId(){
        return this.parentId;
    }
    public void setCategory(String category){
        this.category = category;
    }
    public String getCategory(){
        return this.category;
    }
}