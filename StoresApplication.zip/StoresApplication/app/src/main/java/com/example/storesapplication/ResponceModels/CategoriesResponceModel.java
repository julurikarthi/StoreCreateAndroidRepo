package com.example.storesapplication.ResponceModels;

import java.util.List;

public class CategoriesResponceModel {
    private List<CategoriesModel> categories;

    private String status;

    public void setCategories(List<CategoriesModel> categories){
        this.categories = categories;
    }
    public List<CategoriesModel> getCategories(){
        return this.categories;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
}

