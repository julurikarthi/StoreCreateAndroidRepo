package com.example.storesapplication.ResponceModels;

public class CustomerLoginResponceModel {

    private String customeruserid;
    private String owneruserid;
    private String customername;
    private String email;
    private String phonenumber;
    private String status;


    // Getter Methods

    public String getCustomeruserid() {
        return customeruserid;
    }

    public String getOwneruserid() {
        return owneruserid;
    }

    public String getCustomername() {
        return customername;
    }

    public String getEmail() {
        return email;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public String getStatus() {
        return status;
    }

    // Setter Methods

    public void setCustomeruserid(String customeruserid) {
        this.customeruserid = customeruserid;
    }

    public void setOwneruserid(String owneruserid) {
        this.owneruserid = owneruserid;
    }

    public void setCustomername(String customername) {
        this.customername = customername;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}