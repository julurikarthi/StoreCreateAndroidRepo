package com.example.storesapplication.ResponceModels;

import java.util.List;

public class OfferResponceModel {
    private List<OffersModel> offers;

    private String status;

    public void setOffers(List<OffersModel> offers){
        this.offers = offers;
    }
    public List<OffersModel> getOffers(){
        return this.offers;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
}
