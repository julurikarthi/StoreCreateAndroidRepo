package com.example.storesapplication.ResponceModels;

public class OffersModel {
    private String offerimages;

    private String offerpercentage;

    public void setOfferimages(String offerimages){
        this.offerimages = offerimages;
    }
    public String getOfferimages(){
        return this.offerimages;
    }
    public void setOfferpercentage(String offerpercentage){
        this.offerpercentage = offerpercentage;
    }
    public String getOfferpercentage(){
        return this.offerpercentage;
    }
}