package com.example.storesapplication.ResponceModels;

import java.util.List;

public class OrderResponceModel {
    private List<OrdersModel> orders;

    private String status;

    public void setOrders(List<OrdersModel> orders){
        this.orders = orders;
    }
    public List<OrdersModel> getOrders(){
        return this.orders;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
}
