package com.example.storesapplication.ResponceModels;

public class OrdersModel {
    private String customeruserid;

    private String owneruserid;

    private String orderid;

    private String ordertotalamount;

    private String orderdate;

    private String orderplacedtype;

    private String addressid;

    private String orderstatus;

    private String productid;

    private String productname;

    private String productprice;

    private String productdiscount;

    private String productdescription;

    private String productquantity;

    public void setCustomeruserid(String customeruserid){
        this.customeruserid = customeruserid;
    }
    public String getCustomeruserid(){
        return this.customeruserid;
    }
    public void setOwneruserid(String owneruserid){
        this.owneruserid = owneruserid;
    }
    public String getOwneruserid(){
        return this.owneruserid;
    }
    public void setOrderid(String orderid){
        this.orderid = orderid;
    }
    public String getOrderid(){
        return this.orderid;
    }
    public void setOrdertotalamount(String ordertotalamount){
        this.ordertotalamount = ordertotalamount;
    }
    public String getOrdertotalamount(){
        return this.ordertotalamount;
    }
    public void setOrderdate(String orderdate){
        this.orderdate = orderdate;
    }
    public String getOrderdate(){
        return this.orderdate;
    }
    public void setOrderplacedtype(String orderplacedtype){
        this.orderplacedtype = orderplacedtype;
    }
    public String getOrderplacedtype(){
        return this.orderplacedtype;
    }
    public void setAddressid(String addressid){
        this.addressid = addressid;
    }
    public String getAddressid(){
        return this.addressid;
    }
    public void setOrderstatus(String orderstatus){
        this.orderstatus = orderstatus;
    }
    public String getOrderstatus(){
        return this.orderstatus;
    }
    public void setProductid(String productid){
        this.productid = productid;
    }
    public String getProductid(){
        return this.productid;
    }
    public void setProductname(String productname){
        this.productname = productname;
    }
    public String getProductname(){
        return this.productname;
    }
    public void setProductprice(String productprice){
        this.productprice = productprice;
    }
    public String getProductprice(){
        return this.productprice;
    }
    public void setProductdiscount(String productdiscount){
        this.productdiscount = productdiscount;
    }
    public String getProductdiscount(){
        return this.productdiscount;
    }
    public void setProductdescription(String productdescription){
        this.productdescription = productdescription;
    }
    public String getProductdescription(){
        return this.productdescription;
    }
    public void setProductquantity(String productquantity){
        this.productquantity = productquantity;
    }
    public String getProductquantity(){
        return this.productquantity;
    }
}

