package com.example.storesapplication.ResponceModels;

public class OwnerLoginResponceModel {
    private String owneruserid;

    private String ownername;

    private String email;

    private String phonenumber;

    private String status;

    public String getStorename() {
        return storename;
    }

    public void setStorename(String storename) {
        this.storename = storename;
    }

    private String storename;

    public void setOwneruserid(String owneruserid){
        this.owneruserid = owneruserid;
    }
    public String getOwneruserid(){
        return this.owneruserid;
    }
    public void setOwnername(String ownername){
        this.ownername = ownername;
    }
    public String getOwnername(){
        return this.ownername;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getEmail(){
        return this.email;
    }
    public void setPhonenumber(String phonenumber){
        this.phonenumber = phonenumber;
    }
    public String getPhonenumber(){
        return this.phonenumber;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
}
