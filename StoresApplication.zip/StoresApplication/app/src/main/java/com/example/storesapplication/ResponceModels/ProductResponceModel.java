package com.example.storesapplication.ResponceModels;

import java.util.List;

public class ProductResponceModel {

    private List<ProductsModel> products;

    private String status;

    public void setProducts(List<ProductsModel> products){
        this.products = products;
    }
    public List<ProductsModel> getProducts(){
        return this.products;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public String getStatus(){
        return this.status;
    }
}
