package com.example.storesapplication.ResponceModels;

public class ProductsModel {

    private String productid;

    private String owneruserid;

    private String productname;

    private String description;

    private String price;

    private String discountprice;

    private String discountpercentage;

    private String producttype;

    private String sizes;

    private String productdetails;

    private String images;

    private String category;

    public void setProductid(String productid){
        this.productid = productid;
    }
    public String getProductid(){
        return this.productid;
    }
    public void setOwneruserid(String owneruserid){
        this.owneruserid = owneruserid;
    }
    public String getOwneruserid(){
        return this.owneruserid;
    }
    public void setProductname(String productname){
        this.productname = productname;
    }
    public String getProductname(){
        return this.productname;
    }
    public void setDescription(String description){
        this.description = description;
    }
    public String getDescription(){
        return this.description;
    }
    public void setPrice(String price){
        this.price = price;
    }
    public String getPrice(){
        return this.price;
    }
    public void setDiscountprice(String discountprice){
        this.discountprice = discountprice;
    }
    public String getDiscountprice(){
        return this.discountprice;
    }
    public void setDiscountpercentage(String discountpercentage){
        this.discountpercentage = discountpercentage;
    }
    public String getDiscountpercentage(){
        return this.discountpercentage;
    }
    public void setProducttype(String producttype){
        this.producttype = producttype;
    }
    public String getProducttype(){
        return this.producttype;
    }
    public void setSizes(String sizes){
        this.sizes = sizes;
    }
    public String getSizes(){
        return this.sizes;
    }
    public void setProductdetails(String productdetails){
        this.productdetails = productdetails;
    }
    public String getProductdetails(){
        return this.productdetails;
    }
    public void setImages(String images){
        this.images = images;
    }
    public String getImages(){
        return this.images;
    }
    public void setCategory(String category){
        this.category = category;
    }
    public String getCategory(){
        return this.category;
    }
}

